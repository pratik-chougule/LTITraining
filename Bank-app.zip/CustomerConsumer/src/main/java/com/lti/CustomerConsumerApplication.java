package com.lti;

import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestClientException;

import com.lti.controllers.ConsumerControllerClient;

@SpringBootApplication
public class CustomerConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerConsumerApplication.class, args);
		
		ApplicationContext ctx = SpringApplication.run(
				CustomerConsumerApplication.class, args);
		
		ConsumerControllerClient consumerControllerClient=ctx.getBean(ConsumerControllerClient.class);
		System.out.println(consumerControllerClient);
		try {
			consumerControllerClient.getCustomer();
		} catch (RestClientException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}
	
	@Bean
	public  ConsumerControllerClient  consumerControllerClient()
	{
		return  new ConsumerControllerClient();
	}
	}


