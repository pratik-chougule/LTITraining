export class Address{

    public street!: string;
    public city!:string;
    public state!:string;
    public zipcode!:string;
    

}