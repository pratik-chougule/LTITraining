import { Address } from "./customer-address";


 export class Customer {
        
            public id!: number;
            public name!: string;
            public age!: number;
           
            public typeOfAccount!: string;

            address: Address = new Address;
 }


