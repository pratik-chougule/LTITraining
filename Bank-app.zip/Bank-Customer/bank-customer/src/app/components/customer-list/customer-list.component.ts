import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { CustomerService } from 'src/app/customer.service';
import { Customer } from 'src/customer';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit {
  [x: string]: any;
  customers!: Observable<Customer[]>;
  customer?:Customer;
  id ='';
  constructor(private customerService:CustomerService,private router:Router) { }

  ngOnInit(): void {
  }
  reloadData(){
    this.customerService.getCustomerList();
  }
  deleteCustomer(id:number){
    this.customerService.deleteCustomer(id)
      .subscribe(
        data=>{
          console.log(data);
          this.reloadData();
        },
        error=>console.log(error));
      
  }

  customerDetails(id:number){
    this.router.navigate(['details',id]);
  }

  updateCustomer(id:number){
    this.router.navigate(['update',id])
  }
  searchById():void{
    this.customer = undefined;
    

    this.customerService.findById(this.id)
      .subscribe(
        (        data: any) => {
          this['customer'] = data;
          console.log(data);
        },
        (        error: any) => {
          console.log(error);
        });
  }

}
