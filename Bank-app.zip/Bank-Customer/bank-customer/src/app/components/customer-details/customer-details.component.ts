import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerService } from 'src/app/customer.service';
import { Customer } from 'src/customer';

@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent implements OnInit {
  [x: string]: any;
  id!: number;
  customer!: Customer;
  constructor(private customerService:CustomerService,private route:ActivatedRoute,private router:Router) { }

  ngOnInit(){
    this.customer = new Customer();
      this.id=this.route.snapshot.params['id'];
      this.customerService.getCustomer(this.id)
      .subscribe(data=>{
        console.log(data)
        this.customer=data;
      },error => console.log(error));
      
      
  }

  list(){
    this.router.navigate(['customers']);
  }
  deleteCustomer() {
    this.customerService.delete(this.customer.id)
      .subscribe(
        (        response: any) => {
          console.log(response);
          this.router.navigate(['/customer']);
        },
        (        error: any) => {
          console.log(error);
        });
  }

}
