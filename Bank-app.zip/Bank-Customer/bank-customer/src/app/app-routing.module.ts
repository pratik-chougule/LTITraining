import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateCustomerComponent } from './components/create-customer/create-customer.component';
import { CustomerDetailsComponent } from './components/customer-details/customer-details.component';
import { CustomerListComponent } from './components/customer-list/customer-list.component';
import { UpdateCustomerComponent } from './components/update-customer/update-customer.component';


const routes: Routes = [
  {path:'', redirectTo: 'customer',pathMatch:'full'},
  {path: 'customers', component:CustomerListComponent},
  {path:'add',component:CreateCustomerComponent},
  {path:'update/:id',component:UpdateCustomerComponent},
  {path: 'details/:id',component:CustomerDetailsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
