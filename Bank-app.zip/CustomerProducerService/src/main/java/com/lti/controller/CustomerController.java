package com.lti.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.model.Customer;
import com.lti.service.CustomerService;


@RestController
@RequestMapping("/bank-api")
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	@GetMapping("/getAllCustomers")
	public ResponseEntity<?> getAllCustomers() {
		List<Customer> customersList = customerService.getAllCustomers();

		if (customersList == null) {
			return new ResponseEntity<>("customers Not Found", HttpStatus.NO_CONTENT);
		} else {
			return new ResponseEntity<>(customersList, HttpStatus.OK);

		}

	}

	@PostMapping("/save")
	public Customer saveCustomer(@RequestBody Customer customer) {

		return customerService.saveCustomer(customer);
		
	}

	@GetMapping("/findByid/{id}")
	
	public ResponseEntity<?> findByid(@PathVariable("id") Integer id) {
		Optional<Customer> customer = customerService.findById(id);
		if (customer != null) {
			return new ResponseEntity<>(customer, HttpStatus.FOUND);
		} else {
			return new ResponseEntity<>("customer Not Found", HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping("/update/{id}")
	public ResponseEntity<?>  saveOrUpdate(@RequestBody Customer c) {

		Customer customer = customerService.saveOrUpdate(c);
		if (customer != null) {
			return new ResponseEntity<>(customer, HttpStatus.CREATED);
		} 
			return new ResponseEntity<>(customer, HttpStatus.FAILED_DEPENDENCY);
		
	}

	@PostMapping("/deleteByid/{id}")
	public ResponseEntity<?> deleteById(@PathVariable("id") Integer id) {
		boolean customer = customerService.deleteById(id);
		if (customer == true) {
			return new ResponseEntity<>(customer, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(customer, HttpStatus.FAILED_DEPENDENCY);
		}
	}

}
