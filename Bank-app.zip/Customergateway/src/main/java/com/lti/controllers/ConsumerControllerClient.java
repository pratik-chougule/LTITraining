package com.lti.controllers;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Controller
public class ConsumerControllerClient {

	
	@RestController
	@RequestMapping("/client")
	public class ConsumerControllerClient {

		@Autowired
		private DiscoveryClient discoveryClient;
		
		@Autowired
		private LoadBalancerClient loadBalancer;
		   
		    @HystrixCommand(fallbackMethod = "client", groupKey = "client",
		            commandKey = "client",
		            threadPoolKey = "clientThread"
		            )
		@GetMapping("/getAllCustomer")
		public ResponseEntity<?> getAllCustomers() throws RestClientException, IOException{
			
			ServiceInstance serviceInstance=loadBalancer.choose("EMPLOYEE-ZUUL-SERVICE");
			String baseUrl=serviceInstance.getUri().toString();
			baseUrl = baseUrl + "/employee-producer/customer-producer/getAllProducts";
			RestTemplate restTemplate = new RestTemplate();
					return	restTemplate.exchange(baseUrl, HttpMethod.GET,getHeaders(),List.class);
		}
		    
		    @HystrixCommand(fallbackMethod = "client", groupKey = "client",
		            commandKey = "client",
		            threadPoolKey = "clientThread"
		            )
		@GetMapping("/getByid/{id}")
		public ResponseEntity<?> getById(@PathVariable("id") Integer id) throws RestClientException, IOException{
			  System.out.println("Entred Into getCoustomerzbyid");
			List<ServiceInstance> instances = discoveryClient.getInstances("CUSTOMER-ZUUL-SERVICE");
			ServiceInstance serviceInstance = instances.get(0);

			String baseUrl = serviceInstance.getUri().toString();
			RestTemplate restTemplate = new RestTemplate();
			baseUrl = baseUrl + "/employee-producer/customer-producer/findByid/"+id;
					return	restTemplate.exchange(baseUrl, HttpMethod.GET,getHeaders(),Object.class);
				
		}
		    
		    @PostMapping("/save")
			public ResponseEntity<?> save(@RequestBody Customer c) throws RestClientException, IOException{
				  System.out.println("Entred Into getCoustomerzbyid");
				List<ServiceInstance> instances = discoveryClient.getInstances("CUSTOMER-ZUUL-SERVICE");
				ServiceInstance serviceInstance = instances.get(0);

				String baseUrl = serviceInstance.getUri().toString();
				RestTemplate restTemplate = new RestTemplate();
				baseUrl = baseUrl + "/employee-producer/customer-producer/save/";
				       return  restTemplate.postForEntity(baseUrl, c, Object.class);				
			}
		
		

		 public String fallback(Throwable hystrixCommand) {
		        return "Fall Back Called in Coustomer Consumer";
		    }

		private static HttpEntity<?> getHeaders() throws IOException {
			HttpHeaders headers = new HttpHeaders();
			headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
			return new HttpEntity<>(headers);
		}
}
