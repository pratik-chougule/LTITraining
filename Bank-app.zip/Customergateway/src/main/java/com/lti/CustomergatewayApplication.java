package com.lti;

import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestClientException;

import com.lti.controllers.ControllerClient;

@SpringBootApplication
@EnableDiscoveryClient
@EnableZuulProxy
public class CustomergatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomergatewayApplication.class, args);
		
		ApplicationContext ctx = SpringApplication.run(
				CustomergatewayApplication.class, args);
		
		ControllerClient ControllerClient=ctx.getBean(ControllerClient.class);
		System.out.println(ControllerClient);
		try {
			ControllerClient.getCustomer();
		} catch (RestClientException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Bean
	public  ControllerClient  controllerClient()
	{
		return  new ControllerClient();
	}
		
	}
