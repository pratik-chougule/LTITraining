package com.lti.filter;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.support.RequestContext;

import com.netflix.zuul.ZuulFilter;

public class ErrorFilter extends ZuulFilter {
	private static org.slf4j.Logger log = LoggerFactory.getLogger(PreFilter.class);

	@Override
	public String filterType() {
		return "error";
	}

	@Override
	public int filterOrder() {
		return 1;
	}

	@Override
	public boolean shouldFilter() {
		return true;
	}

	@Override
	public Object run() {
		
		
		HttpServletResponse response=RequestContext.getCurrentContext().getResponde();
		log.info("ErrorFilter: "+String.format("response status is %d",response.getStatus());
		return null;
	}

}